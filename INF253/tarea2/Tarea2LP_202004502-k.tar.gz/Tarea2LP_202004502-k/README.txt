Nombre: Diego Eduardo Paz Letelier
Rol: 202004502-k

El programa se compila con makefile, utilizando el comando "make".
Agregué tres funciones extras para ayudarme con el desarrollo de la tarea, su funcionamiento
está explicado en los comentarios de la funcion.

Estas funciones son: SeleccionarEspacio, Intercambiar y limites.