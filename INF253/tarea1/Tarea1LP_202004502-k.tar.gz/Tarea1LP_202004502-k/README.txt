Nombre: Diego Eduardo Paz Letelier
Rol: 202004502-K

El programa de momento no puede procesar el condicional debido a su complejidad
y preferí terminar el resto de las operaciones antes, tampoco procesa los parentesis
y los errores, esto ultimo porque no encontre una forma de reconocer/guardar los
caracteres de la linea que no eran reconocidos por las expresiones regulares
sin tener que hacer harta manipulacion de strings