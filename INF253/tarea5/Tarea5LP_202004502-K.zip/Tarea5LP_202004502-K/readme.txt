Nombre: Diego Eduardo Paz Letelier
Rol: 202004502-k

La tarea se desarrollo con SWI-Prolog

El problema 1 no logré que se aplicara a todos los elementos de la lista puesto que falla en el ultimo al no haber tail

El problema 2 no tuve tiempo para hacerlo
