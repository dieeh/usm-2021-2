Nombre: Diego Eduardo Paz Letelier
Rol: 202004502-k

La tarea se compila con el makefile utilizando el comando 'make' y luego se ejecuta 
con el comando 'make run'.
//Para que funcione el makefile, este se debe ejecutar desde la ubicacion en donde está//

Agregué 4 atributos más a la clase jugador para facilitar el desarrollo de algunos metodos,
estos atributos son

-jugador.level
-jugador.vida_max
-jugador.energia_max
-jugador.mana_max
