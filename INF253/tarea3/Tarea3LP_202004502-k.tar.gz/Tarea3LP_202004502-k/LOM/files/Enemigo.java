//package INF253.tarea3;
package LOM.files;

interface Enemigo {
    public abstract void combate(Jugador jugador);
}
